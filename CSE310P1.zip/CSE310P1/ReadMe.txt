CSE 310 Project 1 - Hash Table with Custom Hash Function
--------------------------------------------------------

### Author:
- Name: John Johnson
- ASU ID: 1225272178(if required)

### Description:
This program implements a **chaining-based hash table** to store **string tokens** read from an input file.  
The hash function **categorises tokens by their first letter**, ensuring:
- Collision resolution is handled via **linked lists (chaining).**
- The program prints:
  1. The **contents of the first 5 slots** in the hash table.
  2. The **length of each slot**.
  3. The **standard deviation** of slot lengths.

---

### **Files Included**
